from server import Servidor



if __name__ == '__main__':
    port = 3245
    host = 'localhost'
    server = Servidor(port, host)
